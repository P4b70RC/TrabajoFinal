package Cinemar;

public class Registro {
	

}
